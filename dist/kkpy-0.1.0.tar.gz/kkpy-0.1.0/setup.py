# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['kkpy']

package_data = \
{'': ['*'], 'kkpy': ['SHP/*']}

install_requires = \
['Bottleneck>=1.3.2,<2.0.0',
 'Cartopy>=0.18.0,<0.19.0',
 'arm-pyart>=1.11.3,<2.0.0',
 'dask>=2020.12.0,<2021.0.0',
 'descartes>=1.1.0,<2.0.0',
 'geopandas>=0.8.1,<0.9.0',
 'haversine>=2.3.0,<3.0.0',
 'matplotlib>=3.3.3,<4.0.0',
 'netCDF4>=1.5.5,<2.0.0',
 'numpy>=1.19.4,<2.0.0',
 'pandas>=1.1.5,<2.0.0',
 'scikit-image>=0.18.1,<0.19.0',
 'scipy>=1.5.4,<2.0.0',
 'wradlib>=1.9.0,<2.0.0',
 'xarray>=0.16.2,<0.17.0']

setup_kwargs = {
    'name': 'kkpy',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Kwonil Kim',
    'author_email': 'kwonil.kim.0@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
